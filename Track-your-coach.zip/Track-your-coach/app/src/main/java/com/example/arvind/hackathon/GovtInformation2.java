package com.example.arvind.hackathon;

public class GovtInformation2 {

    public String city1;
    public String city2;
    public String busNumber;
    public String seatAvail;

    public GovtInformation2(){

    }

    public GovtInformation2(String city1, String city2, String busNumber, String seatAvail) {
        this.city1 = city1;
        this.city2 = city2;
        this.busNumber = busNumber;
        this.seatAvail = seatAvail;
    }

}
