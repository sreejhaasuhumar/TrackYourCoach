package com.example.arvind.hackathon;

public class UserInformation {

    public String name;
    public String phone;
    public String category;

    public UserInformation(){

    }

    public UserInformation(String name, String phone, String category) {
        this.name = name;
        this.phone = phone;
        this.category = category;
    }
}
