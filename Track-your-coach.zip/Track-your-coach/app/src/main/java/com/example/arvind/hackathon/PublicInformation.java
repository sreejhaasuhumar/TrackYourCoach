package com.example.arvind.hackathon;

public class PublicInformation {

    public String name;
    public String from;
    public String to;
    public String busStop;
    public String numberCount;


    public PublicInformation(){

    }

    public PublicInformation(String name, String from, String to, String busStop, String numberCount) {

        this.name = name;
        this.from = from;
        this.to = to;
        this.busStop = busStop;
        this.numberCount = numberCount;

    }

}
