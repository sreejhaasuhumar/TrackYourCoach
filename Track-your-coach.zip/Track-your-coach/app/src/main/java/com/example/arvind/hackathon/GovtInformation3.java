package com.example.arvind.hackathon;



public class GovtInformation3 {

    String uid;
    String seatAvail;

    public GovtInformation3(){

    }

    public GovtInformation3(String uid, String seatAvail) {
        this.uid = uid;
        this.seatAvail = seatAvail;
    }

}
