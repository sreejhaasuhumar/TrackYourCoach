package com.example.arvind.hackathon;

public class GovtInformation {

    public String from;
    public String to;
    public String busNumber;

    public GovtInformation(){

    }

    public GovtInformation(String from, String to, String busNumber) {
        this.from = from;
        this.to = to;
        this.busNumber = busNumber;
    }

}


