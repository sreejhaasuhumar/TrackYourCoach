package com.example.arvind.hackathon;

/**
 * Created by ARVIND on 4/1/2017.
 */

public class UserInformation2 {

    public String name;
    public String phone;
    public String category;
    public String aadhar;

    public UserInformation2()
    {

    }

    public UserInformation2(String name, String phone, String category, String aadhar) {
        this.name = name;
        this.phone = phone;
        this.category = category;
        this.aadhar = aadhar;
    }
}
