package com.example.arvind.hackathon;

public class PublicInformation1 {

    public String from;
    public String to;

    public PublicInformation1(){

    }

    public PublicInformation1(String from, String to) {
        this.from = from;
        this.to = to;
    }
}
