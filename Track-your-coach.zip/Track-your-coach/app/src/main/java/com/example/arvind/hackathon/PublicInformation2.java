package com.example.arvind.hackathon;

import java.util.List;

public class PublicInformation2 {

    public List<String> list;

    PublicInformation2()
    {

    }

    public PublicInformation2(List<String> list) {
        this.list = list;
    }
}
