package com.example.arvind.hackathon;


public class LocationHelp {

    public double lat;
    public double lon;

    public LocationHelp(){

    }

    public LocationHelp(double lat, double lon) {
        this.lat = lat;
        this.lon = lon;
    }

}
